﻿namespace WebApplication1.services
{
    public class GameManager
    {
    }
}
